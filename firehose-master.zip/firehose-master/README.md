# firehose

The source for [firehose.guide](https://firehose.guide).

## FAQ

- Why does this code suck so much? 

  The short answer is that I wrote it in a weekend when I was a freshman, and every new feature has been crammed on top of the existing JS. Does it work? It works pretty well, I guess? It could definitely be better.

- Please bring Firehose to my school!

  I'm happy to help do this, although I'm not going to write new scrapers (as of July 2020), so there's some work to be done there. Still, if you're interested, I think it's definitely workable.


## License

All rights reserved, for the time being. But if you're interested, please reach out.